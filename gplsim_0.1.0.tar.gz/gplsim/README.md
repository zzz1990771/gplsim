# gplsim

install it simply with the following code in R:
```
install.packages("mgcv")
install.packages("https://github.com/zzz1990771/gplsim/raw/master/gplsim_0.1.0.tar.gz", repos=NULL)
library(gplsim)
?gplsim
```
